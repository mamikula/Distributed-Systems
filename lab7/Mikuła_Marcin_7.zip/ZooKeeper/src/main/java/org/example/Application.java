package org.example;

import org.apache.zookeeper.*;

import java.io.IOException;
import java.util.*;

public class Application implements Watcher {
    private final ZooKeeper zooKeeper;
    private Process process;

    public Application() throws IOException {
        this.zooKeeper = new ZooKeeper("localhost:2182", 3000, this);
    }

    public void run() throws InterruptedException, KeeperException {
        zooKeeper.addWatch("/z", AddWatchMode.PERSISTENT_RECURSIVE);
        while (true) {
        }
    }

    @Override
    public void process(WatchedEvent event) {
        if (event.getType() == Event.EventType.NodeCreated) {
            handleNodeCreatedEvent(event);
        } else if (event.getType() == Event.EventType.NodeDeleted) {
            handleNodeDeletedEvent(event);
        }
    }

    private void handleNodeCreatedEvent(WatchedEvent event) {
        System.out.println("zNode created, path: " + event.getPath());
        try {
            printTree();
        } catch (IOException | InterruptedException | KeeperException e) {
            e.printStackTrace();
        }

        if (Objects.equals(event.getPath(), "/z")) {
            openExternalApp();
        } else {
            try {
                int numChildren = zooKeeper.getAllChildrenNumber("/z");
                System.out.println("zNode /z number of children: " + numChildren);
            } catch (KeeperException | InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void handleNodeDeletedEvent(WatchedEvent event) {
        System.out.println("zNode deleted, path: " + event.getPath());
        if (Objects.equals(event.getPath(), "/z")) {
            System.out.println("Killing app");
            process.destroy();
        }
    }

    private void openExternalApp() {
        System.out.println("Opening app...");
        String appLocation = "\"C:\\Program Files\\Microsoft Office\\root\\Office16\\EXCEL.EXE\"";
        try {
            System.out.println("app: " + process.info());
            ProcessBuilder builder = new ProcessBuilder(appLocation);
            process = builder.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void printTree() throws IOException, InterruptedException, KeeperException {
        List<String> tree = getTree();
        for (String child : tree) {
            String formattedPath = formatNodePath(child);
            System.out.println(formattedPath);
        }
    }

    private List<String> getTree() throws InterruptedException, KeeperException {
        List<String> tree = new ArrayList<>();
        traverseTree("/z", "", tree);
        return tree;
    }

    private void traverseTree(String node, String indent, List<String> tree) throws InterruptedException, KeeperException {
        String formattedPath = formatNodePath(node);
        tree.add(indent + formattedPath);

        List<String> children = zooKeeper.getChildren(node, false);
        for (String child : children) {
            String childNode = node + "/" + child;
            traverseTree(childNode, indent + "\t", tree);
        }
    }

    private String formatNodePath(String nodePath) {
        String[] parts = nodePath.split("/");
        String nodeName = parts[parts.length - 1];
        return "/" + nodeName;
    }
}
