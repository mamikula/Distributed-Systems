import { loadPackageDefinition, credentials } from "@grpc/grpc-js";
import { loadSync } from "@grpc/proto-loader";
import path from "path";
import { createInterface } from "readline";

const PROTO_PATH = path.join(
  new URL(import.meta.url).pathname, 
  "../../protos/weather_notifier.proto"
);

const packageDefinition = loadSync(
    PROTO_PATH,
    {keepCase: true,
     longs: String,
     enums: String,
     defaults: true,
     oneofs: true
    });

const weatherNotifier = loadPackageDefinition(packageDefinition).weather_notifier;

const handleCall = call => {
  call.on("data", (data) => {
    console.log("--------------------");
    console.log(`City: ${data.city}`);
    console.log(`Temperature: ${data.temperature}`);
    console.log(`Sky: ${data.sky}`);
    data.falls.length ? console.log("Falls:") : console.log("No falls");
    data.falls.forEach(fall => {
      console.log(`    Type: ${fall.type}, Intensity: ${fall.intensity}`) ;
    });
    console.log("--------------------");
  });
  call.on("end", () => console.log("Connection finished"));
  call.on("error", (e) => console.error(`Connection broken with error: ${e}`));
  // call.on("status", (status) => console.log(`Connection returned status: ${status}`));
}

const main = () => {
  const target = process.env.ADDRESS || "localhost:50051";
  const client = new weatherNotifier.WeatherNotifier(target,
                                       credentials.createInsecure());

  const readline = createInterface({
    input: process.stdin,
    output: process.stdout,
    terminal: false
  });

  const calls = [];

  readline.on("line", line => {
    const args = line.split(" ");
    let sub = {};
    
    switch (args[0]) {
      case "periodic":
        sub = {interval: parseInt(args[1]), cities: args.slice(2)};
        calls.push(client.subscribePeriodic(sub));
        handleCall(calls.at(-1));
        console.log(`Subscribtion nr ${calls.length-1}`);
        break;
      case "oncond":
        switch (args[1]) {
          case "temperature":
            sub = {cities: args.slice(3), temperature: parseInt(args[2])};
            break;
          case "is_night":
            sub = {cities: args.slice(3), is_night: args[2] === "true"};
            break;
          case "sky":
            sub = {cities: args.slice(3), sky: args[2]};
            break;
          case "fall":
            sub = {cities: args.slice(4), fall: {type: args[2], intensity: args[3]}};
            break;
        }
        calls.push(client.subscribeOnCondition(sub));
        handleCall(calls.at(-1));
        console.log(`Subscribtion nr ${calls.length-1}`);
        break;
      case "cancel":
        calls.at(parseInt(args[1])).cancel();
        console.log(`Cancelled subscribtion nr ${args[1]}`);
        break;
      default:
        console.error("Invalid command!");
    }
  })
}

main();
