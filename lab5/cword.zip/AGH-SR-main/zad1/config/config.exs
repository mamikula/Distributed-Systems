import Config

config :chat,
  address: {127, 0, 0, 1},
  port: 4040,
  multicast_address: {224, 0, 0, 55},
  multicast_port: 5999
