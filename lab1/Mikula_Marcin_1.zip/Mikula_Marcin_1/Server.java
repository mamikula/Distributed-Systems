import java.io.IOException;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.concurrent.Executors;
import java.util.Collections;
import java.net.Socket;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.List;

public class Server {
    private static final List<ClientMessageHandler> clientsMessagesHandlers = Collections.synchronizedList(new ArrayList<>());

    public static void main(String[] args) {
        ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(10);

        System.out.println("### SERVER ###");
        int portNumber = 12345;

        try (ServerSocket serverSocket = new ServerSocket(portNumber)) {
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("New client connected");

                ClientMessageHandler clientMessageHandler = new ClientMessageHandler(clientSocket, clientsMessagesHandlers);
                clientsMessagesHandlers.add(clientMessageHandler);
                executor.execute(clientMessageHandler);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}