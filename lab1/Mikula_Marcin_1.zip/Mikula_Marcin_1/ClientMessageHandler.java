import java.io.IOException;
import java.io.BufferedReader;
import java.util.List;
import java.io.InputStreamReader;
import java.net.Socket;
import java.io.PrintWriter;

public class ClientMessageHandler implements Runnable {
    private final List<ClientMessageHandler> clients;
    private final PrintWriter out;
    private final BufferedReader in;
    private String nick;

    public ClientMessageHandler(Socket clientSocket, List<ClientMessageHandler> clients) throws IOException {
        this.clients = clients;
        out = new PrintWriter(clientSocket.getOutputStream(), true);
        in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
    }

    @Override
    public void run() {
        try {
            this.nick = in.readLine();
            System.out.println("New client connected, nick: " + this.nick);

            while (true) {
                String message = in.readLine();
                clients.forEach(client -> {
                    if (!client.nick.equals(this.nick)) {
                        System.out.println("Sending to " + client.nick);
                        client.out.println(nick + ": " + message);
                    }
                });
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
