import java.io.IOException;
import java.io.BufferedReader;

public record Listener(BufferedReader in) implements Runnable {

    @Override
    public void run() {
        try {
            while (true) {
                String message = in.readLine();
                System.out.println(message + "\n");
            }
        } catch (
                IOException e) {
            e.printStackTrace();
        }
    }
}
